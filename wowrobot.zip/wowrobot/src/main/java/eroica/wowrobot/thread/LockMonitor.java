package eroica.wowrobot.thread;

import java.io.IOException;
import java.util.Arrays;

import eroica.wowrobot.util.ThreadUtils;

public class LockMonitor extends Thread {
	private static LockMonitor SINGLETON;
	private static volatile boolean SCROLL_LOCK_STATE = false;
	private static volatile boolean NUM_LOCK_STATE = false;
	private static volatile boolean CAPS_LOCK_STATE = false;

	private volatile boolean syncRequired = true;

	@Override
	public void run() {
		while (true) {
			try {
				Process p = Runtime.getRuntime()
						.exec("java -cp D:\\Programming\\Java\\workspace\\getlockstate\\bin GetLockState");
				String[] status = new String(p.getInputStream().readAllBytes()).trim().split(" ");
//				System.out.println(Arrays.toString(status));
				SCROLL_LOCK_STATE = Boolean.parseBoolean(status[0]);
				NUM_LOCK_STATE = Boolean.parseBoolean(status[1]);
				CAPS_LOCK_STATE = Boolean.parseBoolean(status[2]);
				syncRequired = false;
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
			ThreadUtils.sleep(400);
		}
	}

	public static void getLockState() {
		if (SINGLETON == null || !SINGLETON.isAlive()) {
			SINGLETON = new LockMonitor();
			SINGLETON.syncRequired = true;
			SINGLETON.start();
			while (SINGLETON.syncRequired) {
				ThreadUtils.sleep(100);
			}
		}
	}

	private static boolean isScrollLocked() {
		getLockState();
		return SCROLL_LOCK_STATE;
	}

	private static boolean isNumLocked() {
		getLockState();
		return NUM_LOCK_STATE;
	}

	private static boolean isCapsLocked() {
		getLockState();
		return CAPS_LOCK_STATE;
	}

	public static boolean isRobotOn() {
		return isScrollLocked();
	}

	public static boolean isMultiAttackOn() {
		return isNumLocked();
	}

	public static boolean isAutoBoostOn() {
		return isCapsLocked();
	}

}
