package eroica.wowrobot.thread;

import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import eroica.wowrobot.key.KeyUtils;
import eroica.wowrobot.util.ThreadUtils;

public class ScreenCapturer extends Thread {
	private static ScreenCapturer SINGLETON;
	private static volatile BufferedImage SCREEN_IMAGE;

	private volatile boolean syncRequired = true;
	private volatile long lastRunMillis;

//	@Override
//	public void run() {
//		while (true) {
//			if (syncRequired || LockMonitor.isRobotOn())
//				SCREEN_IMAGE = KeyUtils.ROBOT
//						.createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
//			lastRunMillis = System.currentTimeMillis();
//
//			syncRequired = false;
////			System.out.println("ScreenCapturer..." + lastRunMillis);
////			try {
////				ImageIO.write(SCREEN_IMAGE, "bmp", new File("d:\\abc\\" + lastRunMillis + ".bmp"));
////			} catch (IOException e) {
////				e.printStackTrace();
////			}
//			ThreadUtils.sleep(100);
//		}
//	}

//	public static BufferedImage getScreenImage() {
//		if (SINGLETON == null || !SINGLETON.isAlive()) {
//			SINGLETON = new ScreenCapturer();
//			SINGLETON.syncRequired = true;
//			SINGLETON.start();
//			while (SINGLETON.syncRequired) {
//				ThreadUtils.sleep(40);
//			}
//		} else if (System.currentTimeMillis() - SINGLETON.lastRunMillis > 500) {
//			SINGLETON.syncRequired = true;
//			while (SINGLETON.syncRequired) {
//				ThreadUtils.sleep(40);
//			}
//		}
//		return SCREEN_IMAGE;
//	}
	public static BufferedImage getScreenImage() {
		return KeyUtils.ROBOT.createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
	}
}
