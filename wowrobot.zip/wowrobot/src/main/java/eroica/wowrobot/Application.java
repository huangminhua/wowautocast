package eroica.wowrobot;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import eroica.wowrobot.key.KeyUtils;
import eroica.wowrobot.strategy.Strategy;
import eroica.wowrobot.strategy.hunter.BeastMastery;
import eroica.wowrobot.strategy.hunter.Shooter;
import eroica.wowrobot.thread.LockMonitor;
import eroica.wowrobot.thread.ScreenCapturer;
import eroica.wowrobot.util.ThreadUtils;

public class Application {

	public static void main(String[] args) throws InterruptedException {
		if (LockMonitor.isRobotOn())
			KeyUtils.turnOff();
//		run(new Shooter());
		run(new BeastMastery());
	}

	public static void run(Strategy strategy) {

		while (true) {
			System.out.println("LockMonitor.isRobotOn()=" + LockMonitor.isRobotOn());
			if (!LockMonitor.isRobotOn()) // Scroll Lock未打开的状态下，继续等待
			{
				ThreadUtils.sleep(400);
			} else {
				BufferedImage screenCapture = ScreenCapturer.getScreenImage();
				strategy.operate(screenCapture);
				ThreadUtils.sleep(200);

				// debug
//				try {
//					ImageIO.write(screenCapture, "bmp",
//							new File(String.valueOf("d:\\abc\\" + System.currentTimeMillis() + ".bmp")));
//				} catch (IOException e) {
//					e.printStackTrace();
//				}
			}
		}
	}
}
