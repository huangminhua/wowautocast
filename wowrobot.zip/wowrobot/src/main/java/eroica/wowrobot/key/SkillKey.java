package eroica.wowrobot.key;

import java.awt.event.KeyEvent;

public enum SkillKey {

	SKILL_1(false, 0, '1'), SKILL_2(false, 1, '2'), SKILL_3(false, 2, '3'), SKILL_4(false, 3, '4'),
	SKILL_5(false, 4, '5'), SKILL_6(false, 5, '6'), SKILL_7(false, 6, '7'), SKILL_8(false, 7, '8'),
	SKILL_9(false, 8, '9'), SKILL_10(false, 9, '0'), SKILL_11(false, 10, '-'), SKILL_12(false, 11, '='),
	SKILL_ADDITIONAL_1(true, 0, KeyEvent.VK_SHIFT, '7'), SKILL_ADDITIONAL_2(true, 1, KeyEvent.VK_SHIFT, '8'),
	SKILL_ADDITIONAL_3(true, 2, KeyEvent.VK_SHIFT, '9'), SKILL_ADDITIONAL_4(true, 3, KeyEvent.VK_SHIFT, '0'),
	SKILL_ADDITIONAL_5(true, 4, KeyEvent.VK_SHIFT, '-'), SKILL_ADDITIONAL_6(true, 5, KeyEvent.VK_SHIFT, '='),
	SKILL_ADDITIONAL_7(true, 6, KeyEvent.VK_SHIFT, '1'), SKILL_ADDITIONAL_8(true, 7, KeyEvent.VK_SHIFT, '2'),
	SKILL_ADDITIONAL_9(true, 8, KeyEvent.VK_SHIFT, '3'), SKILL_ADDITIONAL_10(true, 9, KeyEvent.VK_SHIFT, '4'),
	SKILL_ADDITIONAL_11(true, 10),//用於判斷公共cd，用不使用的技能的白色圖標
	SKILL_ADDITIONAL_12(true, 11);//用於判斷戰鬥狀態，用坐騎

	private boolean additional;
	private int index;
	private int[] castKey;

	private SkillKey(boolean additional, int index, int... castKey) {
		this.additional = additional;
		this.index = index;
		this.castKey = castKey;
	}

	public boolean isAdditional() {
		return additional;
	}

	public int getIndex() {
		return index;
	}

	public int[] getCastKey() {
		return castKey;
	}

}
