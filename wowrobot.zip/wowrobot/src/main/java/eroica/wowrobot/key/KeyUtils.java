package eroica.wowrobot.key;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;

import eroica.wowrobot.thread.LockMonitor;
import eroica.wowrobot.util.ThreadUtils;

public class KeyUtils {
	public static Robot ROBOT;
	static {
		try {
			ROBOT = new Robot();
		} catch (AWTException e) {
			throw new RuntimeException(e);
		}
	}

	public static void turnOff() {
		Toolkit.getDefaultToolkit().setLockingKeyState(KeyEvent.VK_SCROLL_LOCK, false);
		while (LockMonitor.isRobotOn()) {
			ThreadUtils.sleep(100);
		}
	}

	public static void cast(int... key) {
		for (int i = 0; i < key.length; i++) {
			ROBOT.keyPress(key[i]);
			ThreadUtils.sleep(10);
		}

		for (int i = key.length - 1; i >= 0; i--) {
			ROBOT.keyRelease(key[i]);
			ThreadUtils.sleep(10);
		}
	}

	public static void cast(SkillKey sk) {
		cast(sk.getCastKey());
	}
}
