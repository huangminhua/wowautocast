package eroica.wowrobot.test;

import java.awt.Color;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

import javax.imageio.ImageIO;

import eroica.wowrobot.util.MathUtils;
import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;

public class Test {

	public static void main(String[] args) throws IOException, TesseractException {
		Tesseract t = new Tesseract();
		t.setLanguage("eng");
		BufferedImage bi = ImageIO.read(new File("D:\\10m.bmp"));


		for (int x = 0; x < bi.getWidth(); x++) {
			for (int y = 0; y < bi.getHeight(); y++) {
				Color c = new Color(bi.getRGB(x, y));
				int colorSum = c.getRed() + c.getGreen() + c.getBlue();
				c = new Color(colorSum/3, colorSum/3, colorSum/3);
				bi.setRGB(x, y, c.getRGB());
			}
		}


		ImageIO.write(bi, "bmp", new File("d:\\c.bmp"));

		String s = t.doOCR(bi);
		System.out.println(s);
		
//		BufferedImage bi = ImageIO.read(new File("D:\\33.png"));
//		Image i = bi.getScaledInstance(26, 26, Image.SCALE_AREA_AVERAGING);
//		bi = new BufferedImage(26, 26, BufferedImage.TYPE_INT_RGB);
//		bi.getGraphics().drawImage(i, 0, 0, null);
//		ImageIO.write(bi, "bmp", new File("d:\\c.bmp"));
		
		
		BufferedImage bi1 = ImageIO.read(new File("D:\\26.png"));
		BufferedImage bi2 = ImageIO.read(new File("D:\\c.bmp"));
		
		for (int i = 0; i < 26; i++) {
			for (int j = 0; j < 26; j++) {
				Color c1 = new Color(bi1.getRGB(i, j));
				Color c2 = new Color(bi2.getRGB(i, j));
				
				
			}
		}
		
	}

}
