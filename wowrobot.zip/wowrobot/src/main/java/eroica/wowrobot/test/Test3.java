package eroica.wowrobot.test;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Iterator;

public class Test3 {

	public static void main(String[] args) throws IOException {
		int[][] all = new int[201][201];
		int centerXY = 100;
		int outerRadius = 60;
		int innerRadius = 12;
		for (int i = 0; i < all.length; i++) {
			for (int j = 0; j < all[i].length; j++) {
				int x = i - centerXY;
				int y = j - centerXY;
				int distance = x * x + y * y;
				if (distance <= outerRadius * outerRadius && distance >= innerRadius * innerRadius) {
					all[i][j] = 1;
				}
			}
		}

		BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream("d:\\a.txt")));
		while (true) {
			String line = br.readLine();
			if (line == null)
				break;
			else {
				String[] l = line.split(" ");
				int offsetX = Integer.valueOf(l[0]);
				int offsetY = Integer.valueOf(l[1]);
				int overlap = Integer.valueOf(l[3]);

				int[][] canvas = new int[201][201];

				for (int i = 0; i < all.length; i++) {
					for (int j = 0; j < all[i].length; j++) {
						int x = i - centerXY;
						int y = j - centerXY;
						int distance = x * x + y * y;
						if (distance <= outerRadius * outerRadius && distance >= innerRadius * innerRadius) {
							canvas[i][j] = 1;
						}
					}
				}

				for (int i = 0; i < all.length; i++) {
					for (int j = 0; j < all[i].length; j++) {
						int x = i - centerXY + offsetX;
						int y = j - centerXY + offsetY;
						int distance = x * x + y * y;
						if (distance <= outerRadius * outerRadius && distance >= innerRadius * innerRadius) {
							canvas[i][j]++;
						}
					}
				}

				int twos = 0;
				for (int i = 0; i < all.length; i++) {
					for (int j = 0; j < all[i].length; j++) {
//						System.out.print(canvas[i][j]);
						if (canvas[i][j] == 2)
							twos++;
					}
//					System.out.println();
				}
//				System.out.println(twos);
				if (overlap != twos)
					throw new RuntimeException(overlap + " " + twos);
				else {
					System.out.println("ok");
				}
			}
		}

		br.close();
	}

}
