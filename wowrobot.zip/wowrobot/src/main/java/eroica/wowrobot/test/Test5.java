package eroica.wowrobot.test;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import eroica.wowrobot.analyzer.ScreenImageAnalyzer;
import eroica.wowrobot.analyzer.screen.CastingStatus;
import eroica.wowrobot.analyzer.screen.SelfStatus;
import eroica.wowrobot.analyzer.screen.SkillBar;
import eroica.wowrobot.analyzer.screen.TargetStatus;
import eroica.wowrobot.key.SkillKey;

public class Test5 {

	public static void main(String[] args) throws IOException {
		BufferedImage bi = ImageIO.read(new File("D:\\abc\\1661563013573.bmp"));
//		ScreenImageAnalyzer.initStandard(bi, null, null);
		bi = ImageIO.read(new File("D:\\abc\\WoWScrnShot_082722_163048.jpg"));
		ScreenImageAnalyzer sia = ScreenImageAnalyzer.analyze(bi);
//		SelfStatus ss = sia.getSelfStatus();
//		System.out.println(ss.getVitalityRate());
//		System.out.println(ss.getEnergyRate());
//		System.out.println(ss.isBeingAttacked());
//		System.out.println(ss.isPetExist());
//		System.out.println(ss.getPetVitalityRate());

		TargetStatus ts = sia.getTargetStatus();
		System.out.println(ts.isTargetSelected());
		System.out.println(ts.isEnemy());
		System.out.println(ts.getVitalityRate());
		System.out.println(ts.isAttackable());

//		CastingStatus cs = sia.getCastingStatus();
//		System.out.println(cs.isCasting());
//		System.out.println(cs.getCastingRate());

//		SkillBar sb = sia.getSkillBar();
//		System.out.println(sb.isHighlighted(SkillKey.SKILL_ADDITIONAL_3));
//		System.out.println(sb.isHighlighted(SkillKey.SKILL_ADDITIONAL_4));
//		System.out.println(sb.isHighlighted(SkillKey.SKILL_ADDITIONAL_5));
//		System.out.println(sb.isHighlighted(SkillKey.SKILL_ADDITIONAL_6));

//		System.out.println(sb.isSkillAvailable(SkillKey.SKILL_ADDITIONAL_7));
//		System.out.println(sb.isSkillAvailable(SkillKey.SKILL_ADDITIONAL_8));
//		System.out.println(sb.isSkillAvailable(SkillKey.SKILL_ADDITIONAL_9));
//		System.out.println(sb.isSkillAvailable(SkillKey.SKILL_ADDITIONAL_10));
	}

}
