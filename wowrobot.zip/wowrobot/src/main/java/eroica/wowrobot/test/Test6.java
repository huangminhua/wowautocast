package eroica.wowrobot.test;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import eroica.wowrobot.analyzer.ScreenImageAnalyzer;
import eroica.wowrobot.analyzer.screen.BuffIcon;
import eroica.wowrobot.analyzer.screen.BuffStatus;

public class Test6 {
	public static void main(String[] args) throws IOException {
		BufferedImage bi = ImageIO.read(new File("D:\\abc\\1661522096230.bmp"));
		ScreenImageAnalyzer sia = ScreenImageAnalyzer.analyze(bi);
		BuffStatus bs = sia.getBuffStatus();
		System.out.println(bs.hasBuff(BuffIcon.SKILLED_SHOOT));
		System.out.println(bs.hasBuff(BuffIcon.PREDATORS_DESIRE));
		
		
	}
}
