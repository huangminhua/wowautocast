package eroica.wowrobot.test;

import java.awt.Toolkit;
import java.awt.event.KeyEvent;

import eroica.wowrobot.key.KeyUtils;
import eroica.wowrobot.util.ThreadUtils;

public class Test4 {

	public static void main(String[] args) {
		// 2,3 13 4,1 17

		while (true) {
			ThreadUtils.sleep(1000);
			System.out.println(Toolkit.getDefaultToolkit().getLockingKeyState(KeyEvent.VK_NUM_LOCK));
		}
	}

}
