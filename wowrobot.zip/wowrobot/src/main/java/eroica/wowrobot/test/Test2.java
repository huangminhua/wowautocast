package eroica.wowrobot.test;

import java.awt.AWTException;
import java.awt.Color;
import java.awt.Robot;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;

import javax.imageio.ImageIO;

import eroica.wowrobot.analyzer.screen.MapImage;
import eroica.wowrobot.analyzer.screen.SkillBar;
import eroica.wowrobot.util.MathUtils;
import eroica.wowrobot.util.ThreadUtils;

public class Test2 {

	public static void main(String[] args) throws AWTException, IOException {
		BufferedImage screenCapture = ImageIO.read(new File("D:\\abc\\1661573775431.bmp"));
//		SkillBar.initStandard(screenCapture, null, null);
//		SkillBar.STANDARD.saveIcon();
	}

}
