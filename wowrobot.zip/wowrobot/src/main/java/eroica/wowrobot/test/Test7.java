package eroica.wowrobot.test;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import eroica.wowrobot.analyzer.ScreenImageAnalyzer;
import eroica.wowrobot.analyzer.screen.BuffIcon;
import eroica.wowrobot.analyzer.screen.BuffStatus;

public class Test7 {

	public static BufferedImage compareImg(BufferedImage bia, BufferedImage bib) {
		BufferedImage bic = new BufferedImage(28, 28, BufferedImage.TYPE_INT_RGB);
		int sumRGB = 0;
		for (int i = 0; i < 28; i++) {
			for (int j = 0; j < 28; j++) {
				Color ca = new Color(bia.getRGB(j, i));
				Color cb = new Color(bib.getRGB(j, i));
				int r = Math.abs(ca.getRed() - cb.getRed());
				int g = Math.abs(ca.getGreen() - cb.getGreen());
				int b = Math.abs(ca.getBlue() - cb.getBlue());
				Color cc = new Color(r, g, b);
				bic.setRGB(j, i, cc.getRGB());
				sumRGB += r + g + b;
			}
		}
		System.out.println(sumRGB);
//		try {
//			ImageIO.write(bic, "bmp", new File(String.valueOf("d:\\bcd\\" + System.currentTimeMillis() + ".bmp")));
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
		return bic;
	}

	public static void main(String[] args) throws IOException {
		BufferedImage a = ImageIO.read(new File("D:\\bcd\\a.bmp"));
		BufferedImage b = ImageIO.read(new File("D:\\bcd\\b.bmp"));
		BufferedImage c = ImageIO.read(new File("D:\\bcd\\c.bmp"));
		BufferedImage d = ImageIO.read(new File("D:\\bcd\\d.bmp"));

		compareImg(a, b);
		compareImg(c, d);
		compareImg(b, d);
	}
}
