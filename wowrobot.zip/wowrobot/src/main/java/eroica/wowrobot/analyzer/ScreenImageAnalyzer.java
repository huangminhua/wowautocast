package eroica.wowrobot.analyzer;

import java.awt.image.BufferedImage;
import java.util.List;

import eroica.wowrobot.analyzer.screen.AllyStatus;
import eroica.wowrobot.analyzer.screen.BuffStatus;
import eroica.wowrobot.analyzer.screen.CastingStatus;
import eroica.wowrobot.analyzer.screen.MapImage;
import eroica.wowrobot.analyzer.screen.SelfStatus;
import eroica.wowrobot.analyzer.screen.SkillBar;
import eroica.wowrobot.analyzer.screen.TargetStatus;

public class ScreenImageAnalyzer {
	private SelfStatus selfStatus;
	private TargetStatus targetStatus;
	private AllyStatus allyStatus;
	private BuffStatus buffStatus;
	private MapImage mapImage;
	private CastingStatus castingStatus;
	private SkillBar skillBar;

	private BufferedImage screenCapture;
	
	public static boolean isInitiated() {
		return SkillBar.isInitiated();
	}

	public static void initStandard(BufferedImage screenCapture, List<Integer> baseSkillDark,
			List<Integer> appendSkillDark) {
		SkillBar.initStandard(screenCapture, baseSkillDark, appendSkillDark);
	}

	public static ScreenImageAnalyzer analyze(BufferedImage screenCapture) {
		return new ScreenImageAnalyzer(screenCapture);
	}

	public ScreenImageAnalyzer(BufferedImage screenCapture) {
		this.screenCapture = screenCapture;
	}

	public SelfStatus getSelfStatus() {
		if (selfStatus == null)
			selfStatus = new SelfStatus(screenCapture);
		return selfStatus;
	}

	public TargetStatus getTargetStatus() {
		if (targetStatus == null)
			targetStatus = new TargetStatus(screenCapture);
		return targetStatus;
	}

	public AllyStatus getAllyStatus() {
		if (allyStatus == null)
			allyStatus = new AllyStatus(screenCapture);
		return allyStatus;
	}

	public BuffStatus getBuffStatus() {
		if (buffStatus == null)
			buffStatus = new BuffStatus(screenCapture);
		return buffStatus;
	}

	public MapImage getMapImage() {
		if (mapImage == null)
			mapImage = new MapImage(screenCapture);
		return mapImage;
	}

	public CastingStatus getCastingStatus() {
		if (castingStatus == null)
			castingStatus = new CastingStatus(screenCapture);
		return castingStatus;
	}

	public SkillBar getSkillBar() {
		if (skillBar == null)
			skillBar = new SkillBar(screenCapture);
		return skillBar;
	}

}
