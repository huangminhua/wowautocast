package eroica.wowrobot.analyzer.screen;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.imageio.ImageIO;

import eroica.wowrobot.key.SkillKey;
import eroica.wowrobot.util.MathUtils;

public class SkillBar {
	private static int BASE_SKILL_BAR_X = 448;
	private static int ADDITIONAL_SKILL_BAR_X = 991;
	private static int SKILL_BAR_Y = 1012;// -14?
	private static int UPPER_SKILL_BAR_Y = 963;// -14?
	private static int CELL_SIDE_LENGTH = 32;
	private static int CELL_INTEVAL = 42;

	public static int EXP_BAR_TOP_Y = 1037;
	public static int EXP_BAR_LEFT_X = 442;
	public static int EXP_BAR_RIGHT_X = 1237;

	private static SkillBar STANDARD = null;
	private static List<Integer> BASE_SKILL_STANDARD_DARK;
	private static List<Integer> ADDITIONAL_SKILL_STANDARD_DARK;

	private BufferedImage[] BASE_SKILL_IMAGE = new BufferedImage[12];
	private BufferedImage[] ADDITIONAL_SKILL_IMAGE = new BufferedImage[12];

	public static boolean isInitiated() {
		return STANDARD != null;
	}

	public static void initStandard(BufferedImage screenCapture, List<Integer> baseSkillDark,
			List<Integer> additionalSkillDark) {
		if (expBarExists(screenCapture)) {
			SKILL_BAR_Y -= 14;
			UPPER_SKILL_BAR_Y -= 14;
		}

		STANDARD = new SkillBar(screenCapture);
		BASE_SKILL_STANDARD_DARK = baseSkillDark == null ? new ArrayList<Integer>() : baseSkillDark;
		ADDITIONAL_SKILL_STANDARD_DARK = additionalSkillDark == null ? new ArrayList<Integer>() : additionalSkillDark;
	}

	private static boolean expBarExists(BufferedImage screenCapture) {
		int sumDiff = 0;
		for (int x = EXP_BAR_LEFT_X; x <= EXP_BAR_RIGHT_X; x++) {
			Color c = new Color(screenCapture.getRGB(x, EXP_BAR_TOP_Y));
			int r = c.getRed();
			int g = c.getGreen();
			int b = c.getBlue();
			sumDiff += MathUtils.max(r, g, b) - MathUtils.min(r, g, b);
		}
		return sumDiff < 10 * (EXP_BAR_RIGHT_X - EXP_BAR_LEFT_X);
	}

	public SkillBar(BufferedImage screenCapture) {
		for (int i = 0; i < BASE_SKILL_IMAGE.length; i++) {
			BASE_SKILL_IMAGE[i] = screenCapture.getSubimage(BASE_SKILL_BAR_X + i * CELL_INTEVAL, SKILL_BAR_Y,
					CELL_SIDE_LENGTH, CELL_SIDE_LENGTH);
		}
		for (int i = 0; i < ADDITIONAL_SKILL_IMAGE.length / 2; i++) {
			ADDITIONAL_SKILL_IMAGE[i] = screenCapture.getSubimage(ADDITIONAL_SKILL_BAR_X + i * CELL_INTEVAL,
					SKILL_BAR_Y, CELL_SIDE_LENGTH, CELL_SIDE_LENGTH);
		}
		for (int i = ADDITIONAL_SKILL_IMAGE.length / 2; i < ADDITIONAL_SKILL_IMAGE.length; i++) {
			ADDITIONAL_SKILL_IMAGE[i] = screenCapture.getSubimage(ADDITIONAL_SKILL_BAR_X + (i - 6) * CELL_INTEVAL,
					UPPER_SKILL_BAR_Y, CELL_SIDE_LENGTH, CELL_SIDE_LENGTH);
		}
	}

//	public void saveIcon() {
//		int i = 0;
//		for (BufferedImage bsi : BASE_SKILL_IMAGE) {
//			try {
//				ImageIO.write(bsi, "bmp", new File(String.valueOf("d:\\bcd\\b" + i++ + ".bmp")));
//			} catch (IOException e) {
//				e.printStackTrace();
//			}
//		}
//		for (BufferedImage bsi : ADDITIONAL_SKILL_IMAGE) {
//			try {
//				ImageIO.write(bsi, "bmp", new File(String.valueOf("d:\\bcd\\a" + i++ + ".bmp")));
//			} catch (IOException e) {
//				e.printStackTrace();
//			}
//		}
//	}

	public boolean isSkillAvailable(SkillKey sk) {
		return isSkillAvailable(sk.getIndex(), sk.isAdditional());
	}

	// TODO 目前高亮並冷卻中時返回的是true
	private boolean isSkillAvailable(int skillIndex, boolean isAdditionalSkill) {
		BufferedImage image = isAdditionalSkill ? ADDITIONAL_SKILL_IMAGE[skillIndex] : BASE_SKILL_IMAGE[skillIndex];
		BufferedImage standardImage = isAdditionalSkill ? STANDARD.ADDITIONAL_SKILL_IMAGE[skillIndex]
				: STANDARD.BASE_SKILL_IMAGE[skillIndex];
//		try {
//			ImageIO.write(standardImage, "bmp", new File("D:\\std." + isAdditionalSkill + skillIndex + ".bmp"));
//			ImageIO.write(image, "bmp", new File("D:\\" + isAdditionalSkill + skillIndex + ".bmp"));
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}

		int sumLightDiff = 0;
		for (int i = 0; i < 6; i++) {
			Color colorCurrent = new Color(image.getRGB(15, i));
			Color colorStandard = new Color(standardImage.getRGB(15, i));
			sumLightDiff = sumLightDiff + colorCurrent.getRed() + colorCurrent.getGreen() + colorCurrent.getBlue()
					- colorStandard.getRed() - colorStandard.getGreen() - colorStandard.getBlue();
		}
//		System.out.println(sumLightDiff);

		boolean standardDark = isAdditionalSkill ? ADDITIONAL_SKILL_STANDARD_DARK.contains(skillIndex)
				: BASE_SKILL_STANDARD_DARK.contains(skillIndex);
		if (standardDark)
			return sumLightDiff > 200;
		else
			return sumLightDiff >= 0;
	}

	public boolean isHighlighted(SkillKey sk) {
		return isHighlighted(sk.getIndex(), sk.isAdditional());
	}

	private boolean isHighlighted(int skillIndex, boolean isAdditionalSkill) {
		BufferedImage image = isAdditionalSkill ? ADDITIONAL_SKILL_IMAGE[skillIndex] : BASE_SKILL_IMAGE[skillIndex];
		int sumColor = 0;
		// 2*32全是亮黃色
		for (int i = 0; i < 2; i++) {
			for (int j = 0; j < CELL_SIDE_LENGTH; j++) {
				Color c = new Color(image.getRGB(j, i));
				sumColor += c.getRed() + c.getGreen() + c.getBlue();
			}
		}
//		System.out.println(sumColor / (2 * CELL_SIDE_LENGTH));
		return sumColor / (2 * CELL_SIDE_LENGTH) > 550;
	}

}
