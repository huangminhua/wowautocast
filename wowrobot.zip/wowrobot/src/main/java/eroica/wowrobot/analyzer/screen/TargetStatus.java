package eroica.wowrobot.analyzer.screen;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.util.Arrays;

import eroica.wowrobot.util.MathUtils;

public class TargetStatus {

	// 目标存在
	private static int TARGET_FRAME_LEFT_X = 259;
	private static int TARGET_FRAME_RIGHT_X = 369;
	private static int[] TARGET_FRAME_GREY_Y = new int[] { 26, 45, 56, 67 };// 一般是灰色的，精英是黄色的
	private static int[] TARGET_FRAME_BLACK_Y = new int[] { 27, 44, 46, 55, 57, 66 };

	// 目标类型
	private static int TARGET_HEAD_LEFT_X = 258;
	private static int TARGET_HEAD_RIGHT_X = 370;
	private static int TARGET_HEAD_TOP_Y = 30;
	private static int TARGET_HEAD_BOTTOM_Y = 40;

	// 血条
	private static int VITALITY_LEFT_X = 257;
	private static int VITALITY_RIGHT_X = 372;
	private static int VITALITY_Y = 51;

	// 能量条
	private static int ENERGY_LEFT_X = 257;
	private static int ENERGY_RIGHT_X = 372;
	private static int ENERGY_Y = 62;

	// 被攻击显示红色提示
	private static int BEING_ATTACKED_LEFT_X = 258;
	private static int BEING_ATTACKED_RIGHT_X = 379;
	private static int BEING_ATTACKED_Y = 23;

	private BufferedImage screenCapture;

	public TargetStatus(BufferedImage screenCapture) {
		this.screenCapture = screenCapture;
	}

	public boolean isTargetSelected() {
		// 一般怪特征：max(r,g,b)-min(r,g,b)平均<10
		int sumDiff = 0;
		// 精英怪特征：r平均>180，且1<sum(r)/sum(g)<1.5，且sum(r)/sum(b)>3
		int sumR = 0;
		int sumG = 0;
		int sumB = 0;

		for (int i = 0; i < TARGET_FRAME_GREY_Y.length; i++) {
			int y = TARGET_FRAME_GREY_Y[i];
			for (int j = TARGET_FRAME_LEFT_X; j <= TARGET_FRAME_RIGHT_X; j++) {
				Color c = new Color(screenCapture.getRGB(j, y));
//				System.out.println(c);
				sumR += c.getRed();
				sumG += c.getGreen();
				sumB += c.getBlue();
				sumDiff += MathUtils.max(c.getRed(), c.getGreen(), c.getBlue())
						- MathUtils.min(c.getRed(), c.getGreen(), c.getBlue());
			}
		}
//		System.out.println(sumDiff);
//		System.out.println(sumR+" "+sumG+" "+sumB);
		if ((sumDiff / ((TARGET_FRAME_RIGHT_X - TARGET_FRAME_LEFT_X + 1) * TARGET_FRAME_GREY_Y.length) >= 10)
				&& !(sumR / ((TARGET_FRAME_RIGHT_X - TARGET_FRAME_LEFT_X + 1) * TARGET_FRAME_GREY_Y.length) > 180
						&& sumR > sumG && sumR < sumG * 1.5 && sumR > sumB * 3))
			return false;
//		System.out.println("pass");
		// 特征：这六行是黑的，rgb平均<=30
		int sumColor = 0;
		for (int i = 0; i < TARGET_FRAME_BLACK_Y.length; i++) {
			int y = TARGET_FRAME_BLACK_Y[i];
			for (int j = TARGET_FRAME_LEFT_X; j <= TARGET_FRAME_RIGHT_X; j++) {
				Color c = new Color(screenCapture.getRGB(j, y));
//				System.out.println(c.toString() + j + y);
				sumColor += c.getRed() + c.getGreen() + c.getBlue();
			}
		}
//		System.out.println(sumColor / (TARGET_FRAME_BLACK_Y.length * (TARGET_FRAME_RIGHT_X - TARGET_FRAME_LEFT_X + 1)));
		return sumColor / (TARGET_FRAME_BLACK_Y.length * (TARGET_FRAME_RIGHT_X - TARGET_FRAME_LEFT_X + 1)) < 15;
	}

	public boolean isEnemy() {
		// 特征：sum(r)远大于sum(g)+sum(b)
		int sumR = 0;
		int sumG = 0;
		int sumB = 0;
		for (int i = TARGET_HEAD_TOP_Y; i <= TARGET_HEAD_BOTTOM_Y; i++) {
			for (int j = TARGET_HEAD_LEFT_X; j <= TARGET_HEAD_RIGHT_X; j++) {
				Color c = new Color(screenCapture.getRGB(j, i));
//				System.out.println(c.toString() + j + i);
				sumR += c.getRed();
				sumG += c.getGreen();
				sumB += c.getBlue();
			}
		}
		System.out.println(Arrays.asList(sumR, sumG, sumB));
		return sumR > (sumG + sumB) * 3.5;
	}

	public boolean isAttackable() {
		if (getVitalityRate() <= 0)
			return false;
		if (isEnemy())
			return true;
		// 特征：sum(r)和sum(g)差不多，且远大于sum(b)
		int sumR = 0;
		int sumG = 0;
		int sumB = 0;
		for (int i = TARGET_HEAD_TOP_Y; i <= TARGET_HEAD_BOTTOM_Y; i++) {
			for (int j = TARGET_HEAD_LEFT_X; j <= TARGET_HEAD_RIGHT_X; j++) {
				Color c = new Color(screenCapture.getRGB(j, i));
//				System.out.println(c.toString() + j + i);
				sumR += c.getRed();
				sumG += c.getGreen();
				sumB += c.getBlue();
			}
		}
//		System.out.println(Arrays.asList(sumR, sumG, sumB));
		return sumR * 1.2 > sumG && sumG * 1.2 > sumR && sumR > sumB * 5;
	}

	public int getVitalityRate() {
		for (int i = VITALITY_LEFT_X; i <= VITALITY_RIGHT_X; i++) {
			Color c = new Color(screenCapture.getRGB(i, VITALITY_Y));
//			System.out.println(c);
			// 特征：g>(r+b)*3
			if (!(c.getGreen() > (c.getRed() + c.getBlue()) * 3)) {
				return (i - VITALITY_LEFT_X) * 100 / (VITALITY_RIGHT_X - VITALITY_LEFT_X + 1);
			}
		}
		return 100;
	}

}
