package eroica.wowrobot.analyzer.screen;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.imageio.ImageIO;

public enum BuffIcon {

	SKILLED_SHOOT(), PREDATORS_DESIRE();

	private BufferedImage icon;

	private BuffIcon() {
		InputStream is = null;

		try {
			is = new FileInputStream(
					"D:\\Programming\\Java\\workspace\\wowrobot\\src\\main\\resources\\buff\\" + this.name() + ".bmp");
			icon = ImageIO.read(is);
//			ImageIO.write(icon, "bmp", new File(String.valueOf("d:\\bcd\\" + this.name() + ".bmp")));
		} catch (IOException e) {
			throw new RuntimeException(e);
		} finally {
			if (is != null)
				try {
					is.close();
				} catch (IOException e) {
				}
		}
	}

	public BufferedImage getIcon() {
		return icon;
	}

}
