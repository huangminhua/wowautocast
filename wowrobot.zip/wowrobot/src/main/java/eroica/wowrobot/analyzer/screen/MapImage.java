package eroica.wowrobot.analyzer.screen;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.imageio.ImageIO;

import eroica.wowrobot.util.Debugger;
import eroica.wowrobot.util.MathUtils;

public class MapImage {
//
//	private static int MAP_CENTER_X = 1592;
//	private static int MAP_CENTER_Y = 92;
//	private static int OUTER_RADIUS = 60;
//	private static int INNER_RADIUS = 12;
//	private static boolean[][] CHECK_MAP = new boolean[OUTER_RADIUS * 2 + 1][OUTER_RADIUS * 2 + 1];
//	private static List<PixelOrdering> PIXEL_ORDERINGS = new ArrayList<PixelOrdering>();
//	private static List<PixelOrdering> COMPARE_ORDERINGS = new ArrayList<PixelOrdering>();
//
//	private static BufferedImage MAP_IMAGE_STANDARD = null;
//
//	static {
//		for (int x = -OUTER_RADIUS; x <= OUTER_RADIUS; x++) {
//			for (int y = -OUTER_RADIUS; y <= OUTER_RADIUS; y++) {
//				int distance = x * x + y * y;
//				if (distance <= OUTER_RADIUS * OUTER_RADIUS && distance >= INNER_RADIUS * INNER_RADIUS) {
//					CHECK_MAP[x + OUTER_RADIUS][y + OUTER_RADIUS] = true;
//					PIXEL_ORDERINGS.add(new PixelOrdering(x, y));
//				}
//				if (distance <= OUTER_RADIUS * OUTER_RADIUS) {
//					COMPARE_ORDERINGS.add(new PixelOrdering(x, y));
//				}
//			}
//		}
//		PIXEL_ORDERINGS.sort(null);
//		COMPARE_ORDERINGS.sort(null);
//	}
//
	public MapImage(BufferedImage screenCapture) {
		// TODO Auto-generated constructor stub
	}
//
//	public static void setMapImageStandard(BufferedImage screenCapture) {
//		MAP_IMAGE_STANDARD = screenCapture.getSubimage(MAP_CENTER_X - OUTER_RADIUS, MAP_CENTER_Y - OUTER_RADIUS,
//				OUTER_RADIUS * 2 + 1, OUTER_RADIUS * 2 + 1);
////		for (int i = 0; i < CHECK_MAP.length; i++) {
////			for (int j = 0; j < CHECK_MAP[i].length; j++) {
////				if(!CHECK_MAP[i][j])
////					MAP_IMAGE_STANDARD.setRGB(i, j, new Color(255, 255, 255).getRGB());
////			}
////		}
//
////		try {
////			ImageIO.write(MAP_IMAGE_STANDARD, "bmp", new File("d:\\MAP_IMAGE_STANDARD.bmp"));
////		} catch (IOException e) {
////			// TODO Auto-generated catch block
////			e.printStackTrace();
////		}
//	}
//
//	public static PixelOffset getOffset(BufferedImage screenCapture) {
//		BufferedImage mapImageCurrent = screenCapture.getSubimage(MAP_CENTER_X - OUTER_RADIUS,
//				MAP_CENTER_Y - OUTER_RADIUS, OUTER_RADIUS * 2 + 1, OUTER_RADIUS * 2 + 1);
//
//		double minDiffRate = Double.MAX_VALUE;
//		PixelOffset offset = null;
//
//		for (PixelOrdering co : COMPARE_ORDERINGS) {
//			int totalPixels = 0;
//			int totalDiff = 0;
//
//			for (PixelOrdering po : PIXEL_ORDERINGS) {
//				int x = po.getX() + 60;
//				int y = po.getY() + 60;
//				int xa = x + co.x;
//				int ya = y + co.y;
//				if (xa >= 0 && xa < OUTER_RADIUS * 2 + 1 && ya >= 0 && ya < OUTER_RADIUS * 2 + 1 && CHECK_MAP[xa][ya]) {
//					Color c = new Color(MAP_IMAGE_STANDARD.getRGB(x, y));
//					Color ca = new Color(mapImageCurrent.getRGB(xa, ya));
//					totalPixels++;
//					int redDiff = c.getRed() - ca.getRed();
//					int greenDiff = c.getGreen() - ca.getGreen();
//					int blueDiff = c.getBlue() - ca.getBlue();
//					totalDiff += (MathUtils.max(redDiff, greenDiff, blueDiff)
//							- MathUtils.min(redDiff, greenDiff, blueDiff)) * 2;
//					totalDiff += Math.abs(redDiff);
//					totalDiff += Math.abs(greenDiff);
//					totalDiff += Math.abs(blueDiff);
//				}
//			}
//			double diffRate = (double) totalDiff / totalPixels;
//			Debugger.println(co.getX() + " " + co.getY() + " " + totalDiff + " " + totalPixels);
//			if (diffRate < minDiffRate) {
//				minDiffRate = diffRate;
//				offset = new PixelOffset(co.getX(), co.getY());
//			}
//		}
//		return offset;
//	}
//
//	private static class PixelOrdering implements Comparable<PixelOrdering> {
//		private int x;
//		private int y;
//		private int radiusSquare;
//
//		private PixelOrdering(int x, int y) {
//			this.x = x;
//			this.y = y;
//			this.radiusSquare = x * x + y * y;
//		}
//
//		public int getX() {
//			return x;
//		}
//
//		public int getY() {
//			return y;
//		}
//
//		public int getRadiusSquare() {
//			return radiusSquare;
//		}
//
//		@Override
//		public int compareTo(PixelOrdering another) {
//			return this.radiusSquare - another.radiusSquare;
//		}
//
//		@Override
//		public String toString() {
//			return "(" + x + "," + y + ")";
//		}
//
//	}

//	public static void main(String[] args) throws IOException {
//		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("D:\\a.txt")));
//		bw.write(PIXEL_ORDERINGS.toString());
//		bw.close();
//	}
}
