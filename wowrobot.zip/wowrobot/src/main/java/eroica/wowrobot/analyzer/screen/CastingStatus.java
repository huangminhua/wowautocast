package eroica.wowrobot.analyzer.screen;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import eroica.wowrobot.util.MathUtils;

public class CastingStatus {

	// 有宠物的情况下
	private static int[] CASTING_GREY_Y_WITH_PET = new int[] { 836, 837, 838, 852, 853, 854, 855 };
	private static int[] CASTING_GREY_Y_WITHOUT_PET = new int[] { 871, 872, 873, 886, 887, 888, 889 };
	private static int CASTING_LEFT_X = 746;
	private static int CASTING_RIGHT_X = 933;

	private static int CASTING_CENTER_Y_WITH_PET = 846;
	private static int CASTING_CENTER_Y_WITHOUT_PET = 881;

	private BufferedImage screenCapture;

	public CastingStatus(BufferedImage screenCapture) {
		this.screenCapture = screenCapture;
	}

	private int isCasting1() {
		// 特征：max(r,g,b)-min(r,g,b)平均<10
		int sumDiff = 0;
		for (int i = 0; i < CASTING_GREY_Y_WITH_PET.length; i++) {
			int y = CASTING_GREY_Y_WITH_PET[i];
			for (int j = CASTING_LEFT_X; j <= CASTING_RIGHT_X; j++) {
				Color c = new Color(screenCapture.getRGB(j, y));
				sumDiff += MathUtils.max(c.getRed(), c.getGreen(), c.getBlue())
						- MathUtils.min(c.getRed(), c.getGreen(), c.getBlue());
			}
		}
//		System.out.println(sumDiff / ((CASTING_RIGHT_X - CASTING_LEFT_X + 1) * CASTING_GREY_Y_WITH_PET.length));
		if (sumDiff / ((CASTING_RIGHT_X - CASTING_LEFT_X + 1) * CASTING_GREY_Y_WITH_PET.length) < 6)
			return 1;

		sumDiff = 0;
		for (int i = 0; i < CASTING_GREY_Y_WITHOUT_PET.length; i++) {
			int y = CASTING_GREY_Y_WITHOUT_PET[i];
			for (int j = CASTING_LEFT_X; j <= CASTING_RIGHT_X; j++) {
				Color c = new Color(screenCapture.getRGB(j, y));
				sumDiff += MathUtils.max(c.getRed(), c.getGreen(), c.getBlue())
						- MathUtils.min(c.getRed(), c.getGreen(), c.getBlue());
			}
		}
		if (sumDiff / ((CASTING_RIGHT_X - CASTING_LEFT_X + 1) * CASTING_GREY_Y_WITH_PET.length) < 6)
			return 2;
		return 0;

	}

	public boolean isCasting() {
		return isCasting1() > 0;
	}

	public int getCastingRate() {
		int ic1 = isCasting1();
		if (ic1 == 1) {
			for (int i = CASTING_RIGHT_X; i >= CASTING_LEFT_X; i--) {
				Color c = new Color(screenCapture.getRGB(i, CASTING_CENTER_Y_WITH_PET));
//			System.out.println(c.toString() + i);
				if (c.getRed() + c.getGreen() + c.getBlue() > 600)
					return (i - CASTING_LEFT_X + 1) * 100 / (CASTING_RIGHT_X - CASTING_LEFT_X + 1);
			}
			return 0;
		} else if (ic1 == 2) {
			for (int i = CASTING_RIGHT_X; i >= CASTING_LEFT_X; i--) {
				Color c = new Color(screenCapture.getRGB(i, CASTING_CENTER_Y_WITHOUT_PET));
//			System.out.println(c.toString() + i);
				if (c.getRed() + c.getGreen() + c.getBlue() > 600)
					return (i - CASTING_LEFT_X + 1) * 100 / (CASTING_RIGHT_X - CASTING_LEFT_X + 1);
			}
			return 0;
		} else
			return 0;
	}

}
