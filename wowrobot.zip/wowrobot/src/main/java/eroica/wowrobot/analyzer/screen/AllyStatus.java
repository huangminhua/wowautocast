package eroica.wowrobot.analyzer.screen;

import java.awt.image.BufferedImage;

public class AllyStatus {

	public AllyStatus(BufferedImage screenCapture) {
		// TODO Auto-generated constructor stub
	}

}
