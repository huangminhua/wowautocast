package eroica.wowrobot.analyzer.screen;

import java.awt.Color;
import java.awt.image.BufferedImage;
import eroica.wowrobot.util.MathUtils;

public class SelfStatus {
	// 血条
	private static int VITALITY_LEFT_X = 90;
	private static int VITALITY_RIGHT_X = 205;
	private static int VITALITY_Y = 51;

	// 能量条
	private static int ENERGY_LEFT_X = 90;
	private static int ENERGY_RIGHT_X = 205;
	private static int ENERGY_Y = 62;

	// 被攻击显示红色提示
	private static int BEING_ATTACKED_LEFT_X = 84;
	private static int BEING_ATTACKED_RIGHT_X = 203;
	private static int BEING_ATTACKED_Y = 23;

	// 宠物存在
	private static int PET_EXIST_LEFT_X = 110;
	private static int PET_EXIST_RIGHT_X = 173;
	private static int[] PET_EXIST_GREY_Y = new int[] { 85, 86, 94, 102, 103 };
	private static int[] PET_EXIST_BLACK_Y = new int[] { 93, 101 };

	// 宠物血条
	private static int PET_VITALITY_LEFT_X = 108;
	private static int PET_VITALITY_RIGHT_X = 174;
	private static int PET_VITALITY_Y = 90;

	private BufferedImage screenCapture;

	public SelfStatus(BufferedImage screenCapture) {
		this.screenCapture = screenCapture;
	}

	public int getVitalityRate() {
		for (int i = VITALITY_LEFT_X; i <= VITALITY_RIGHT_X; i++) {
			Color c = new Color(screenCapture.getRGB(i, VITALITY_Y));
//			System.out.println(c);
			// 特征：g>(r+b)*3
			if (!(c.getGreen() > (c.getRed() + c.getBlue()) * 3)) {
				return (i - VITALITY_LEFT_X) * 100 / (VITALITY_RIGHT_X - VITALITY_LEFT_X + 1);
			}
		}
		return 100;
	}

	public int getEnergyRate() {
		for (int i = ENERGY_LEFT_X; i <= ENERGY_RIGHT_X; i++) {
			Color c = new Color(screenCapture.getRGB(i, ENERGY_Y));
			// 目前只支持猎人。特征：r>g+w且r>=80，或r>=170
			if (!(c.getRed() > c.getGreen() + c.getBlue() && c.getRed() >= 80 || c.getRed() >= 170)) {
				return (i - ENERGY_LEFT_X) * 100 / (ENERGY_RIGHT_X - ENERGY_LEFT_X + 1);
			}
		}
		return 100;
	}

	public boolean isBeingAttacked() {
		int width = BEING_ATTACKED_RIGHT_X - BEING_ATTACKED_LEFT_X + 1;
		// 特征：r平均>=200，且g平均<5，且b平均<5
		int sumR = 0;
		int sumG = 0;
		int sumB = 0;
		for (int i = BEING_ATTACKED_LEFT_X; i <= BEING_ATTACKED_RIGHT_X; i++) {
			Color c = new Color(screenCapture.getRGB(i, BEING_ATTACKED_Y));
			sumR += c.getRed();
			sumG += c.getGreen();
			sumB += c.getBlue();
		}
		return sumR / width >= 200 && sumG / width < 5 && sumB / width < 5;
	}

	public boolean isPetExist() {
		// 特征：max(r,g,b)-min(r,g,b)平均<10
		int sumDiff = 0;
		for (int i = 0; i < PET_EXIST_GREY_Y.length; i++) {
			int y = PET_EXIST_GREY_Y[i];
			for (int j = PET_EXIST_LEFT_X; j <= PET_EXIST_RIGHT_X; j++) {
				Color c = new Color(screenCapture.getRGB(j, y));
				sumDiff += MathUtils.max(c.getRed(), c.getGreen(), c.getBlue())
						- MathUtils.min(c.getRed(), c.getGreen(), c.getBlue());
			}
		}
		if (sumDiff / ((PET_EXIST_RIGHT_X - PET_EXIST_LEFT_X + 1) * PET_EXIST_GREY_Y.length) >= 10)
			return false;

		// 特征：这两行是黑的，rgb<=10
		for (int i = 0; i < PET_EXIST_BLACK_Y.length; i++) {
			int y = PET_EXIST_BLACK_Y[i];
			for (int j = PET_EXIST_LEFT_X; j <= PET_EXIST_RIGHT_X; j++) {
				Color c = new Color(screenCapture.getRGB(j, y));
				if (c.getRed() > 10 || c.getGreen() > 10 || c.getBlue() > 10)
					return false;
			}
		}
		return true;
	}

	public int getPetVitalityRate() {
		for (int i = PET_VITALITY_LEFT_X; i <= PET_VITALITY_RIGHT_X; i++) {
			Color c = new Color(screenCapture.getRGB(i, PET_VITALITY_Y));
			// 特征：g>=35, rb<=5
			if (!(c.getGreen() >= 35 && c.getRed() <= 5 && c.getBlue() <= 5)) {
				return (i - PET_VITALITY_LEFT_X) * 100 / (PET_VITALITY_RIGHT_X - PET_VITALITY_LEFT_X + 1);
			}
		}
		return 100;
	}
}
