package eroica.wowrobot.analyzer.screen;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Iterator;

import javax.imageio.ImageIO;

public class BuffStatus {

	private static int BUFF_PANEL_LEFT_X = 1204;
	private static int BUFF_PANEL_TOP_Y = 14;
	private static int BUFF_CELL_SIDE_LENGTH = 28;

	private static int BUFF_INTERVAL_X = 35;// (1449-1204)/7
	private static int BUFF_INTERVAL_Y = 45;// 59-14

	private BufferedImage screenCapture;

	private BufferedImage[] buffs;

	public BuffStatus(BufferedImage screenCapture) {
		this.screenCapture = screenCapture;
	}

	public BufferedImage[] getCurrentBuffs() {
		if (buffs != null)
			return buffs;
		else {
			buffs = new BufferedImage[8 * 3];
			for (int i = 0; i < buffs.length / 3; i++) {
				buffs[i] = screenCapture.getSubimage(BUFF_PANEL_LEFT_X + i * BUFF_INTERVAL_X, BUFF_PANEL_TOP_Y,
						BUFF_CELL_SIDE_LENGTH, BUFF_CELL_SIDE_LENGTH);
			}
			for (int i = buffs.length / 3; i < buffs.length * 2 / 3; i++) {
				buffs[i] = screenCapture.getSubimage(BUFF_PANEL_LEFT_X + (i - buffs.length / 3) * BUFF_INTERVAL_X,
						BUFF_PANEL_TOP_Y + BUFF_INTERVAL_Y, BUFF_CELL_SIDE_LENGTH, BUFF_CELL_SIDE_LENGTH);
			}
			for (int i = buffs.length * 2 / 3; i < buffs.length; i++) {
				buffs[i] = screenCapture.getSubimage(BUFF_PANEL_LEFT_X + (i - buffs.length * 2 / 3) * BUFF_INTERVAL_X,
						BUFF_PANEL_TOP_Y + 2 * BUFF_INTERVAL_Y, BUFF_CELL_SIDE_LENGTH, BUFF_CELL_SIDE_LENGTH);
			}

//		for (int i = 0; i < bs.length; i++) {
//			try {
//				ImageIO.write(bs[i], "bmp",
//						new File(String.valueOf("d:\\bcd\\" + i + ".bmp")));
//			} catch (IOException e) {
//				e.printStackTrace();
//			}
//		}
			return buffs;
		}
	}

	public boolean hasBuff(BuffIcon bi) {
		return hasBuff(bi.getIcon());
	}

	public boolean hasBuff(BufferedImage bi) {
		BufferedImage[] bfs = getCurrentBuffs();
		for (BufferedImage bf : bfs) {
			if (compareImg(bf, bi) < 50 * 3 * 28 * 28)
				return true;
		}
		return false;
	}

	public int buffSimilarity(BuffIcon bi) {
		int min = Integer.MAX_VALUE;
		BufferedImage[] bfs = getCurrentBuffs();
		for (BufferedImage bf : bfs) {
			min = Math.min(compareImg(bf, bi.getIcon()), min);
		}
		return min;
	}

	public static int compareImg(BufferedImage bia, BufferedImage bib) {
		int sumRGB = 0;
		for (int i = 0; i < 28; i++) {
			for (int j = 0; j < 28; j++) {
				Color ca = new Color(bia.getRGB(j, i));
				Color cb = new Color(bib.getRGB(j, i));
				int r = Math.abs(ca.getRed() - cb.getRed());
				int g = Math.abs(ca.getGreen() - cb.getGreen());
				int b = Math.abs(ca.getBlue() - cb.getBlue());
				Color cc = new Color(r, g, b);
				sumRGB += r + g + b;
			}
		}
		return sumRGB;
	}
}
