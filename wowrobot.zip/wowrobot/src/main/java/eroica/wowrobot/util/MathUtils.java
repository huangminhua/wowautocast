package eroica.wowrobot.util;

public class MathUtils {
	public static int max(int... n) {
		int r = n[0];
		for (int i = 1; i < n.length; i++) {
			r = Math.max(r, n[i]);
		}
		return r;
	}

	public static int min(int... n) {
		int r = n[0];
		for (int i = 1; i < n.length; i++) {
			r = Math.min(r, n[i]);
		}
		return r;
	}
}
