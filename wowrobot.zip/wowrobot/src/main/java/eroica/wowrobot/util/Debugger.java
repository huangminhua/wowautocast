package eroica.wowrobot.util;

import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.RandomAccessFile;

public class Debugger {

	public static void println(String string) {
		try {
			RandomAccessFile raf = new RandomAccessFile("d:\\a.txt", "rw");
			raf.seek(raf.length());
			raf.writeBytes(string);
			raf.writeBytes("\n");
			raf.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
