package eroica.wowrobot.strategy.hunter;

import java.awt.image.BufferedImage;
import java.util.Arrays;

import eroica.wowrobot.analyzer.ScreenImageAnalyzer;
import eroica.wowrobot.analyzer.screen.BuffIcon;
import eroica.wowrobot.analyzer.screen.BuffStatus;
import eroica.wowrobot.analyzer.screen.CastingStatus;
import eroica.wowrobot.analyzer.screen.SelfStatus;
import eroica.wowrobot.analyzer.screen.SkillBar;
import eroica.wowrobot.analyzer.screen.TargetStatus;
import eroica.wowrobot.key.KeyUtils;
import eroica.wowrobot.key.SkillKey;
import eroica.wowrobot.strategy.Strategy;
import eroica.wowrobot.thread.LockMonitor;
import eroica.wowrobot.util.ThreadUtils;

public class Shooter implements Strategy {
	long now;

	// 斩杀技既在冷却又亮的情况，2秒最多用1次
	long lastCastAdd4Millis = 0;
	long lastCastBoostMillis = 0;

	boolean multiShootCast = false;

	@Override
	public void operate(BufferedImage screenCapture) {
		if (!ScreenImageAnalyzer.isInitiated()) // Scroll Lock打开的状态下，如果还没有读取技能栏图标，则读取，然后将Scroll Lock关闭
		{
			ScreenImageAnalyzer.initStandard(screenCapture, Arrays.asList(10), null);
			KeyUtils.turnOff();
		} else {
			ScreenImageAnalyzer sia = ScreenImageAnalyzer.analyze(screenCapture);
			TargetStatus ts = sia.getTargetStatus();
			CastingStatus cs = sia.getCastingStatus();
			SkillBar sb = sia.getSkillBar();
			SelfStatus ss = sia.getSelfStatus();
			BuffStatus bs = sia.getBuffStatus();

//			System.out.println(
//					"!bs.hasBuff(BuffIcon.SKILLED_SHOOT) buff similarity=" + bs.buffSimilarity(BuffIcon.SKILLED_SHOOT));
//			if (true)
//				return;

			if (ts.isAttackable() && sb.isSkillAvailable(SkillKey.SKILL_ADDITIONAL_11)) {
				now = System.currentTimeMillis();
				if (!LockMonitor.isMultiAttackOn()) {
					if (!(cs.isCasting())) {
//						System.out.println("ss.getEnergyRate()=" + ss.getEnergyRate());
						if (LockMonitor.isAutoBoostOn() && ss.getEnergyRate() <= 80) {
							tryCastBoost(sb);
						}
						if (ss.getEnergyRate() > 10 && now - lastCastAdd4Millis >= 2000
								&& sb.isHighlighted(SkillKey.SKILL_ADDITIONAL_4))// 夺命射击
						{
							KeyUtils.cast(SkillKey.SKILL_ADDITIONAL_4);
							System.out.println("SkillKey.SKILL_ADDITIONAL_4");
							lastCastAdd4Millis = now;
						} else if (ss.getEnergyRate() > 20 && sb.isHighlighted(SkillKey.SKILL_ADDITIONAL_3))// 奇美拉射擊高亮
						{
							KeyUtils.cast(SkillKey.SKILL_ADDITIONAL_3);
							System.out.println("SkillKey.SKILL_ADDITIONAL_3");
						} else if (sb.isHighlighted(SkillKey.SKILL_ADDITIONAL_2)
								&& !sb.isHighlighted(SkillKey.SKILL_ADDITIONAL_3)) // 瞄準射擊高亮
						{
							KeyUtils.cast(SkillKey.SKILL_ADDITIONAL_2);
							System.out.println("SkillKey.SKILL_ADDITIONAL_2");
						} else if (ss.getEnergyRate() <= 70 && sb.isSkillAvailable(SkillKey.SKILL_ADDITIONAL_1))// 急速射擊
						{
							KeyUtils.cast(SkillKey.SKILL_ADDITIONAL_1);
							System.out.println("SkillKey.SKILL_ADDITIONAL_1");
						} else if (ss.getEnergyRate() >= 35 && sb.isSkillAvailable(SkillKey.SKILL_ADDITIONAL_2)) // 瞄準射擊，有了就放
						{
							KeyUtils.cast(SkillKey.SKILL_ADDITIONAL_2);
							System.out.println("SkillKey.SKILL_ADDITIONAL_2");
						} else {
							KeyUtils.cast(SkillKey.SKILL_ADDITIONAL_5);
							System.out.println("SkillKey.SKILL_ADDITIONAL_5");
						}
					}
				} else {
					if (!(cs.isCasting())) {
						if (LockMonitor.isAutoBoostOn() && ss.getEnergyRate() <= 80) {
							tryCastBoost(sb);
						}
						if (ss.getEnergyRate() > 10 && now - lastCastAdd4Millis >= 1000
								&& sb.isSkillAvailable(SkillKey.SKILL_ADDITIONAL_4))// 夺命射击
						{
							KeyUtils.cast(SkillKey.SKILL_ADDITIONAL_4);
							System.out.println("SkillKey.SKILL_ADDITIONAL_4");
							lastCastAdd4Millis = now;
						} else if (!bs.hasBuff(BuffIcon.SKILLED_SHOOT) && !multiShootCast) {
//							System.out.println("!bs.hasBuff(BuffIcon.SKILLED_SHOOT) buff similarity="
//									+ bs.buffSimilarity(BuffIcon.SKILLED_SHOOT));
							if (ss.getEnergyRate() > 25) // 多重射击
							{
								KeyUtils.cast(SkillKey.SKILL_ADDITIONAL_6);
								System.out.println("SkillKey.SKILL_ADDITIONAL_6");
								multiShootCast = true;
							} else {
								KeyUtils.cast(SkillKey.SKILL_ADDITIONAL_5);
								System.out.println("SkillKey.SKILL_ADDITIONAL_5");
							}
						} else if (ss.getEnergyRate() <= 80 && sb.isSkillAvailable(SkillKey.SKILL_ADDITIONAL_1))// 急速射擊
						{
							KeyUtils.cast(SkillKey.SKILL_ADDITIONAL_1);
							System.out.println("SkillKey.SKILL_ADDITIONAL_1");
							multiShootCast = false;
						} else if (ss.getEnergyRate() >= 35 && sb.isHighlighted(SkillKey.SKILL_ADDITIONAL_6)
								&& sb.isSkillAvailable(SkillKey.SKILL_ADDITIONAL_2))// 多重射擊仍然高亮且瞄准射击就绪
						{
							KeyUtils.cast(SkillKey.SKILL_ADDITIONAL_6);
							System.out.println("SkillKey.SKILL_ADDITIONAL_6");
						} else if (ss.getEnergyRate() >= 35 && sb.isSkillAvailable(SkillKey.SKILL_ADDITIONAL_2)) // 瞄準射擊
						{
							KeyUtils.cast(SkillKey.SKILL_ADDITIONAL_2);
							System.out.println("SkillKey.SKILL_ADDITIONAL_2");
							multiShootCast = false;
						} else {
							KeyUtils.cast(SkillKey.SKILL_ADDITIONAL_5);
							System.out.println("SkillKey.SKILL_ADDITIONAL_5");
						}
					}
				}

			}
		}
	}

	private boolean tryCastBoost(SkillBar sb) {
		boolean skillAdd7Avail = sb.isSkillAvailable(SkillKey.SKILL_ADDITIONAL_7);
		boolean skillAdd8Avail = sb.isSkillAvailable(SkillKey.SKILL_ADDITIONAL_8);
		boolean skillAdd9Avail = sb.isSkillAvailable(SkillKey.SKILL_ADDITIONAL_9);

		boolean cast = false;
		if (now - lastCastBoostMillis <= 8000 || skillAdd7Avail && (skillAdd8Avail || skillAdd9Avail))// 上次施法8秒内有啥boost放啥boost
		{
			if (skillAdd7Avail) {
				KeyUtils.cast(SkillKey.SKILL_ADDITIONAL_7);
				cast = true;
			}
			if (skillAdd8Avail)// 饰品
			{
				KeyUtils.cast(SkillKey.SKILL_ADDITIONAL_8);
				cast = true;
			} else if (skillAdd9Avail)// 饰品
			{
				KeyUtils.cast(SkillKey.SKILL_ADDITIONAL_9);
				cast = true;
			}
			return cast;
		}
		return false;
	}
}
