package eroica.wowrobot.strategy.priest;

import java.awt.image.BufferedImage;

import eroica.wowrobot.strategy.Strategy;

public class Voidness implements Strategy {

	@Override
	public void operate(BufferedImage screenCapture) {
		// TODO Auto-generated method stub
		
	}

}
