package eroica.wowrobot.strategy;

import java.awt.image.BufferedImage;

public interface Strategy {

	void operate(BufferedImage screenCapture);

}
