package eroica.wowrobot.strategy.hunter;

import java.awt.image.BufferedImage;
import java.util.Arrays;

import eroica.wowrobot.analyzer.ScreenImageAnalyzer;
import eroica.wowrobot.analyzer.screen.BuffIcon;
import eroica.wowrobot.analyzer.screen.BuffStatus;
import eroica.wowrobot.analyzer.screen.CastingStatus;
import eroica.wowrobot.analyzer.screen.SelfStatus;
import eroica.wowrobot.analyzer.screen.SkillBar;
import eroica.wowrobot.analyzer.screen.TargetStatus;
import eroica.wowrobot.key.KeyUtils;
import eroica.wowrobot.key.SkillKey;
import eroica.wowrobot.strategy.Strategy;
import eroica.wowrobot.thread.LockMonitor;
import eroica.wowrobot.util.ThreadUtils;

public class BeastMastery implements Strategy {
	long now = 0;

	long lastCastAdd1Millis = 0;// 倒刺射击
	long add1Interval = 8000;
	long lastCastAdd2Millis = 0;// 夺命射击，防高亮且冷却的情况
	long lastCastAdd5Millis = 0;// 多重射击
	long add5Interval = 4000;
	long globalCd = 1000;

	long lastCastBoostMillis = 0;

	@Override
	public void operate(BufferedImage screenCapture) {

		if (!ScreenImageAnalyzer.isInitiated()) // Scroll Lock打开的状态下，如果还没有读取技能栏图标，则读取，然后将Scroll Lock关闭
		{
			ScreenImageAnalyzer.initStandard(screenCapture, Arrays.asList(10), null);
			KeyUtils.turnOff();
		} else {
			now = System.currentTimeMillis();
			ScreenImageAnalyzer sia = ScreenImageAnalyzer.analyze(screenCapture);
			TargetStatus ts = sia.getTargetStatus();
			CastingStatus cs = sia.getCastingStatus();
			SkillBar sb = sia.getSkillBar();
			SelfStatus ss = sia.getSelfStatus();
			BuffStatus bs = sia.getBuffStatus();
//			System.out.println(ss.getVitalityRate() + " " + ss.getPetVitalityRate());
//			if(ts.isTargetSelected()&&ts.isEnemy()) 
//SKILL_12用作gcd判斷
//			System.out.println("ts.isAttackable()=" + ts.isAttackable());
//			System.out.println("sb.isSkillAvailable(SkillKey.SKILL_ADDITIONAL_11)="
//					+ sb.isSkillAvailable(SkillKey.SKILL_ADDITIONAL_11));
			if (ts.isAttackable() && sb.isSkillAvailable(SkillKey.SKILL_ADDITIONAL_11)) {
				System.out.println("cs.isCasting()=" + cs.isCasting());
				if (!(cs.isCasting() && cs.getCastingRate() < 95)) {
//					System.out.println("LockMonitor.isMultiAttackOn()=" + LockMonitor.isMultiAttackOn()
//							+ "  sb.isSkillAvailable(SkillKey.SKILL_ADDITIONAL_5)="
//							+ sb.isSkillAvailable(SkillKey.SKILL_ADDITIONAL_5));
					if (!bs.hasBuff(BuffIcon.PREDATORS_DESIRE))// 寵物死了，復活
					{
						KeyUtils.cast(SkillKey.SKILL_ADDITIONAL_6);
						System.out.println("SkillKey.SKILL_ADDITIONAL_6");
					} else if (now - lastCastAdd1Millis >= add1Interval - globalCd - 1200
							&& sb.isSkillAvailable(SkillKey.SKILL_ADDITIONAL_1))// 倒刺射击8秒buff，需保持
					{
						KeyUtils.cast(SkillKey.SKILL_ADDITIONAL_1);
						lastCastAdd1Millis = now;
						System.out.println("SkillKey.SKILL_ADDITIONAL_1");
					} else if (now - lastCastAdd2Millis >= 2000 && sb.isHighlighted(SkillKey.SKILL_ADDITIONAL_2))// 夺命射击
					{
						KeyUtils.cast(SkillKey.SKILL_ADDITIONAL_2);
						System.out.println("SkillKey.SKILL_ADDITIONAL_2");
						lastCastAdd2Millis = now;
					} else if (ss.getPetVitalityRate() < 70 && sb.isSkillAvailable(SkillKey.SKILL_ADDITIONAL_6))// 复活宠物治疗宠物，宠物血量<70%就放
					{
						KeyUtils.cast(SkillKey.SKILL_ADDITIONAL_6);
						System.out.println("SkillKey.SKILL_ADDITIONAL_6");
					} else if (!(LockMonitor.isAutoBoostOn() && tryCastBoost(sb))) {
						if (LockMonitor.isMultiAttackOn() && now - lastCastAdd5Millis >= add5Interval - globalCd
								&& sb.isSkillAvailable(SkillKey.SKILL_ADDITIONAL_5))// 多重射击，4秒buff，群攻時保持
						{
							KeyUtils.cast(SkillKey.SKILL_ADDITIONAL_5);
							System.out.println("SkillKey.SKILL_ADDITIONAL_5");
							lastCastAdd5Millis = now;
						} else if (sb.isSkillAvailable(SkillKey.SKILL_ADDITIONAL_3)) // 杀戮命令，有了就放
						{
							KeyUtils.cast(SkillKey.SKILL_ADDITIONAL_3);
							System.out.println("SkillKey.SKILL_ADDITIONAL_3");
						} else if (sb.isSkillAvailable(SkillKey.SKILL_ADDITIONAL_4)
								&& ((LockMonitor.isMultiAttackOn() && ss.getEnergyRate() > 65)
										|| (!LockMonitor.isMultiAttackOn() && ss.getEnergyRate() > 45))) {
							KeyUtils.cast(SkillKey.SKILL_ADDITIONAL_4);
							System.out.println("SkillKey.SKILL_ADDITIONAL_4");
						}
					}
				}
			}
		}
	}

	private boolean tryCastBoost(SkillBar sb) {
		boolean skillAdd7Avail = sb.isSkillAvailable(SkillKey.SKILL_ADDITIONAL_7);
		boolean skillAdd8Avail = sb.isSkillAvailable(SkillKey.SKILL_ADDITIONAL_8);
		boolean skillAdd9Avail = sb.isSkillAvailable(SkillKey.SKILL_ADDITIONAL_9);
		boolean skillAdd10Avail = sb.isSkillAvailable(SkillKey.SKILL_ADDITIONAL_10);
//		System.out.println(Arrays.asList(skillAdd7Avail, skillAdd8Avail, skillAdd9Avail, skillAdd10Avail));

		if (now - lastCastBoostMillis <= 7000)// 上次施法7秒内有啥boost放啥boost
		{
			return castSequently(skillAdd7Avail, skillAdd8Avail, skillAdd9Avail, skillAdd10Avail);
		} else if (skillAdd7Avail)// 必須有狂野怒火
		{
			int c = 0;
			if (skillAdd8Avail)
				c++;
			if (skillAdd9Avail || skillAdd10Avail)
				c++;
			if (c > 0) {
				return castSequently(skillAdd7Avail, skillAdd8Avail, skillAdd9Avail, skillAdd10Avail);
			}
		}
		return false;
	}

	private boolean castSequently(boolean skillAdd7Avail, boolean skillAdd8Avail, boolean skillAdd9Avail,
			boolean skillAdd10Avail) {
		boolean cast = false;
		if (skillAdd8Avail)// 野性守护
		{
			KeyUtils.cast(SkillKey.SKILL_ADDITIONAL_8);
			cast = true;
		}
		if (skillAdd9Avail)// 饰品
		{
			KeyUtils.cast(SkillKey.SKILL_ADDITIONAL_9);
			cast = true;
		} else if (skillAdd10Avail)// 饰品
		{
			KeyUtils.cast(SkillKey.SKILL_ADDITIONAL_10);
			cast = true;
		}
		if (skillAdd7Avail)// 狂野怒火
		{
			KeyUtils.cast(SkillKey.SKILL_ADDITIONAL_7);
			cast = true;
		}
		if (cast)
			lastCastBoostMillis = now;
		return cast;
	}
}
