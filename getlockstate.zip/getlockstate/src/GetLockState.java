
import java.awt.Toolkit;
import java.awt.event.KeyEvent;

public class GetLockState {

	public static void main(String[] args) {
		System.out.print(Toolkit.getDefaultToolkit().getLockingKeyState(KeyEvent.VK_SCROLL_LOCK));
		System.out.print(" ");
		System.out.print(Toolkit.getDefaultToolkit().getLockingKeyState(KeyEvent.VK_NUM_LOCK));
		System.out.print(" ");
		System.out.println(Toolkit.getDefaultToolkit().getLockingKeyState(KeyEvent.VK_CAPS_LOCK));
	}

}
